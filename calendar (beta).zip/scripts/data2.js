// Morning Walk+Run
let monthlyData = [
  {
    month: 1,
    year: 2024,
    data: [20,22]
  },
  {
    month: 2,
    year: 2024,
    data: [
      1,1,0,0,0,0,0,
      1,1,0,0,0,0,0,
      1,1,1,1,0,1,1,
      1,1,1,1,1
      ]
  },
  {
    month: 3,
    year: 2024,
    data: [2,5,7,8,9]
  }
  // Add more months as needed
];


export default monthlyData;